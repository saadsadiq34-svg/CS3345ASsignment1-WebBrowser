package cs3345assignment1;

import java.io.*;
import java.util.EmptyStackException;

/**
 * BrowserNavigation
 * -----------------
 * This is the "main functionality" class.
 *
 * It manages:
 * - currentPage
 * - backStack (pages behind current)
 * - forwardStack (pages ahead after going back)
 * - history queue (all visited pages, FIFO)
 *
 * It can also:
 * - closeBrowser()        -> save session to file
 * - restoreLastSession()  -> load session from file
 */
public class BrowserNavigation {

    private String currentPage;

    private BrowserStack<String> backStack;
    private BrowserStack<String> forwardStack;
    private BrowserQueue<String> history;

    private static final String SESSION_FILE = "session_data.txt";

    public BrowserNavigation() {
        backStack = new BrowserStack<>();
        forwardStack = new BrowserStack<>();
        history = new BrowserQueue<>();
        currentPage = null;
    }

    /**
     * Visit a NEW website:
     * 1) if current page exists, push it to backStack
     * 2) currentPage = url
     * 3) clear forwardStack (because new navigation breaks the forward path)
     * 4) enqueue url into browsing history
     */
    public String visitWebsite(String url) {
        if (url == null || url.isEmpty()) {
            return "Invalid URL.";
        }

        if (currentPage != null) {
            backStack.push(currentPage);
        }

        currentPage = url;

        // Clear forward history because we branched to a new page
        forwardStack.clear();

        history.enqueue(url);
        return "Now at " + currentPage;
    }

    /**
     * Go back:
     * - requires backStack not empty
     * - current goes to forwardStack
     * - pop backStack becomes new current
     */
    public String goBack() {
        if (backStack.isEmpty()) {
            throw new EmptyStackException();
        }

        if (currentPage != null) {
            forwardStack.push(currentPage);
        }

        currentPage = backStack.pop();
        return "Now at " + currentPage;
    }

    /**
     * Go forward:
     * - requires forwardStack not empty
     * - current goes to backStack
     * - pop forwardStack becomes new current
     */
    public String goForward() {
        if (forwardStack.isEmpty()) {
            throw new EmptyStackException();
        }

        if (currentPage != null) {
            backStack.push(currentPage);
        }

        currentPage = forwardStack.pop();
        return "Now at " + currentPage;
    }

    public String getCurrentPage() {
        return currentPage;
    }

    /**
     * Returns the browsing history as a multi-line string (oldest -> newest).
     * This uses BrowserQueue's iterator (FIFO order).
     */
    public String showHistory() {
        if (history.isEmpty()) {
            return "No browsing history available.";
        }

        StringBuilder sb = new StringBuilder();
        for (String page : history) {
            sb.append(page).append("\n");
        }
        return sb.toString();
    }

    public String clearHistory() {
        history.clear();
        return "Browsing history cleared.";
    }

    /**
     * Save session to file:
     * - CURRENT page
     * - BACK stack (iterated)
     * - FORWARD stack (iterated)
     * - HISTORY queue (iterated)
     */
    public String closeBrowser() {
        try (PrintWriter out = new PrintWriter(new FileWriter(SESSION_FILE))) {

            out.println("CURRENT");
            out.println(currentPage == null ? "null" : currentPage);

            out.println("BACK");
            for (String s : backStack) {        // uses StackIterator
                out.println(s);
            }

            out.println("FORWARD");
            for (String s : forwardStack) {     // uses StackIterator
                out.println(s);
            }

            out.println("HISTORY");
            for (String s : history) {          // uses Queue iterator
                out.println(s);
            }

            out.println("END");
            return "Browser session saved.";

        } catch (IOException e) {
            return "Error saving session: " + e.getMessage();
        }
    }

    /**
     * Restore session from file.
     * We rebuild:
     * - currentPage
     * - backStack
     * - forwardStack
     * - history
     *
     * Note: stacks need careful restore because file stores "top->bottom".
     */
    public String restoreLastSession() {
        File f = new File(SESSION_FILE);
        if (!f.exists()) {
            return "No previous session found.";
        }

        backStack = new BrowserStack<>();
        forwardStack = new BrowserStack<>();
        history = new BrowserQueue<>();
        currentPage = null;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {

            String mode = "";
            String line;

            BrowserStack<String> tempStack = new BrowserStack<>();

            while ((line = br.readLine()) != null) {

                if (line.equals("CURRENT") || line.equals("BACK") || line.equals("FORWARD")
                        || line.equals("HISTORY") || line.equals("END")) {

                    // finalize previous section
                    if (mode.equals("BACK")) {
                        BrowserStack<String> reverse = new BrowserStack<>();
                        while (!tempStack.isEmpty()) reverse.push(tempStack.pop());
                        while (!reverse.isEmpty()) backStack.push(reverse.pop());
                    } else if (mode.equals("FORWARD")) {
                        BrowserStack<String> reverse = new BrowserStack<>();
                        while (!tempStack.isEmpty()) reverse.push(tempStack.pop());
                        while (!reverse.isEmpty()) forwardStack.push(reverse.pop());
                    }

                    mode = line;
                    if (mode.equals("END")) break;
                    continue;
                }

                if (mode.equals("CURRENT")) {
                    currentPage = line.equals("null") ? null : line;
                } else if (mode.equals("BACK") || mode.equals("FORWARD")) {
                    tempStack.push(line);
                } else if (mode.equals("HISTORY")) {
                    history.enqueue(line);
                }
            }

            return "Browser session restored.";

        } catch (IOException e) {
            return "Error restoring session: " + e.getMessage();
        }
    }
}