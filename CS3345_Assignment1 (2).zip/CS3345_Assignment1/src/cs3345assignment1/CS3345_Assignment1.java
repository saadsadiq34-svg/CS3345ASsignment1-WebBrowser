package cs3345assignment1;

import java.util.EmptyStackException;

/**
 * Driver / tester for Assignment 1.
 */
public class CS3345_Assignment1 {

    public static void main(String[] args) {

        BrowserNavigation nav = new BrowserNavigation();

        System.out.println("=== New Session ===");

        System.out.println(nav.visitWebsite("google.com"));
        System.out.println(nav.visitWebsite("utdallas.edu"));
        System.out.println(nav.visitWebsite("github.com"));

        System.out.println("\nCurrent page: " + nav.getCurrentPage());

        System.out.println("\n--- Back ---");
        try {
            System.out.println(nav.goBack());
            System.out.println("Current page: " + nav.getCurrentPage());
        } catch (EmptyStackException e) {
            System.out.println("Cannot go back: no pages in back history.");
        }

        System.out.println("\n--- Forward ---");
        try {
            System.out.println(nav.goForward());
            System.out.println("Current page: " + nav.getCurrentPage());
        } catch (EmptyStackException e) {
            System.out.println("Cannot go forward: no pages in forward history.");
        }

        System.out.println("\n--- History ---");
        System.out.print(nav.showHistory());

        System.out.println("\n=== Closing Browser ===");
        System.out.println(nav.closeBrowser());

        System.out.println("\n=== Restoring Session ===");
        BrowserNavigation nav2 = new BrowserNavigation();
        System.out.println(nav2.restoreLastSession());

        System.out.println("Restored current page: " + nav2.getCurrentPage());

        System.out.println("\n--- Restored History ---");
        System.out.print(nav2.showHistory());
    }
}