package cs3345assignment1;

import java.util.Iterator;

/**
 * BrowserQueue
 * ------------
 * A queue (FIFO) built using our custom circular array (BrowserArrayList).
 *
 * enqueue(x): add to back
 * dequeue(): remove from front
 *
 * Implements Iterable so we can do:
 * for (AnyType x : historyQueue) { ... }
 */
public class BrowserQueue<AnyType> implements Iterable<AnyType> {

    private BrowserArrayList<AnyType> list;

    public BrowserQueue() {
        list = new BrowserArrayList<>();
    }

    public void enqueue(AnyType x) {
        list.addLast(x);
    }

    public AnyType dequeue() {
        return list.removeFirst();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    public void clear() {
        list.doClear();
    }

    /**
     * Queue iteration should be from OLDEST to NEWEST.
     * Since BrowserArrayList iterator already walks logical order from front,
     * we can just delegate.
     */
    @Override
    public Iterator<AnyType> iterator() {
        return list.iterator();
    }
}