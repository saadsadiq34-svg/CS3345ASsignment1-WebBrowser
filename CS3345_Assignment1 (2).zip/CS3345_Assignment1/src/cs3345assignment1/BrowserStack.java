package cs3345assignment1;

import java.util.EmptyStackException;
import java.util.Iterator;

/**
 * BrowserStack
 * ------------
 * Stack (LIFO) built using our custom doubly linked list.
 *
 * push(x): add to top
 * pop(): remove from top
 *
 * Implements Iterable so StackIterator can traverse it when saving session.
 */
public class BrowserStack<AnyType> implements Iterable<AnyType> {

    private BrowserLinkedList<AnyType> list;

    public BrowserStack() {
        list = new BrowserLinkedList<>();
    }

    public void push(AnyType x) {
        list.addFirst(x);
    }

    public AnyType pop() {
        if (isEmpty()) throw new EmptyStackException();
        return list.removeFirst();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public int size() {
        return list.size();
    }

    /**
     * Clears the stack.
     * Useful when we want to discard forward history after visiting a new page.
     */
    public void clear() {
        while (!isEmpty()) pop();
    }

    /**
     * Package-private: StackIterator uses this to access list iteration.
     */
    Iterator<AnyType> internalListIterator() {
        return list.iterator();
    }

    @Override
    public Iterator<AnyType> iterator() {
        return new StackIterator<>(this);
    }
}