
# CS3345 Assignment 1 — Browser Navigation System

## Student Info
- Name: Muhammad Saad Sadiq
- Course: CS3345 Data Structures & Algorithm Analysis
- Instructor: Omar Hamdy
- IDE: NetBeans

---

## Project Summary
This project implements a simplified web browser navigation system using **custom data structures** (no Java built-in stacks/queues/arraylists are used for the core structures).

The browser supports:
- Visiting new websites
- Going back / forward
- Viewing browsing history (FIFO)
- Saving the session to a file when closing
- Restoring the session from that file

---

## Files Included

### 1) `BrowserLinkedList.java`
A custom **doubly linked list** with sentinel nodes:
- `beginMarker` and `endMarker` simplify edge cases.
- Supports add/remove at both ends.
- Implements `Iterable` (linked list iterator).

### 2) `BrowserStack.java`
A custom **stack (LIFO)** built on `BrowserLinkedList`:
- `push(x)` adds to top
- `pop()` removes from top
- Implements `Iterable` so it can be saved using the required stack iterator

### 3) `StackIterator.java`
A **custom iterator** required by the assignment to traverse the stack
when saving session data.

### 4) `BrowserArrayList.java`
A custom **circular array** structure:
- Maintains `front` and `back` indices
- Uses modular arithmetic for wrap-around
- Dynamically resizes with `ensureCapacity`
- Implements `Iterable` (circular array iterator)

### 5) `BrowserQueue.java`
A custom **queue (FIFO)** built on `BrowserArrayList`:
- `enqueue(x)` adds to back
- `dequeue()` removes from front
- Implements `Iterable` for history printing/saving

### 6) `BrowserNavigation.java`
Main functionality class that manages:
- currentPage
- backStack + forwardStack (BrowserStack)
- history (BrowserQueue)
- save session (`closeBrowser()`) to `session_data.txt`
- restore session (`restoreLastSession()`)

### 7) `CS3345_Assignment1.java`
Driver program to test the system.

---

## How to Run (NetBeans)
1. Open the NetBeans project.
2. Make sure all `.java` files are under the package:
   `cs3345assignment1`
3. Run `CS3345_Assignment1.java`.

---

## Session File
The session is saved/restored using:
- `session_data.txt`

---

## Time Complexity (Big-O)
- Stack push/pop: **O(1)** (linked list front operations)
- Queue enqueue/dequeue: **O(1)** amortized (circular array)
- Resizing array: **O(n)** when it happens, but amortized behavior remains efficient
- History iteration: **O(n)**

---

## Notes
- The iterators are implemented so enhanced-for loops can be used.
- No Java collection classes are used for the core Stack/Queue/ArrayList structures.