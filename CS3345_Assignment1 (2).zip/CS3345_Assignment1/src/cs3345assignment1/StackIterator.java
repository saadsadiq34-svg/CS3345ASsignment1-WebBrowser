package cs3345assignment1;

import java.util.Iterator;

/**
 * StackIterator
 * -------------
 * Required custom iterator used when saving stack state (closeBrowser()).
 * Internally delegates to the linked list iterator.
 */
public class StackIterator<AnyType> implements Iterator<AnyType> {

    private Iterator<AnyType> it;

    public StackIterator(BrowserStack<AnyType> stack) {
        this.it = stack.internalListIterator();
    }

    @Override
    public boolean hasNext() {
        return it.hasNext();
    }

    @Override
    public AnyType next() {
        return it.next();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("remove() not supported.");
    }
}