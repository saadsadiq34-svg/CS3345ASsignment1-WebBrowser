package cs3345assignment1;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * BrowserArrayList
 * ----------------
 * A CUSTOM circular array structure (NOT java.util.ArrayList).
 *
 * Key idea: "front" is where the first logical element lives.
 * Elements are stored in a real array, but the queue behavior is circular,
 * meaning indices wrap around using modular arithmetic.
 *
 * This class supports:
 * - addLast(x)   : enqueue-like (push to back)
 * - removeFirst(): dequeue-like (remove from front)
 * - ensureCapacity(): resizing while preserving logical order
 *
 * Also implements Iterable so we can use:
 * for (AnyType x : arrayList) { ... }
 */
public class BrowserArrayList<AnyType> implements Iterable<AnyType> {

    private static final int DEFAULT_CAPACITY = 10;

    private AnyType[] theItems; // the real underlying array
    private int theSize;        // number of elements currently stored
    private int front;          // index of the logical first element
    private int back;           // index of the logical last element

    public BrowserArrayList() {
        doClear();
    }

    /**
     * Resets the structure to an empty state.
     */
    public void doClear() {
        theSize = 0;
        front = 0;
        back = -1; // means "no last element yet"
        ensureCapacity(DEFAULT_CAPACITY);
    }

    public int size() {
        return theSize;
    }

    public boolean isEmpty() {
        return theSize == 0;
    }

    /**
     * Circular increment helper:
     * moves index forward by 1, wrapping around if it hits the end.
     *
     * Example if length=5:
     * increment(0)=1, increment(3)=4, increment(4)=0
     */
    private int increment(int index) {
        return (index + 1) % theItems.length;
    }

    /**
     * Resizes the underlying array to newCapacity
     * while preserving the logical order (front ... back).
     *
     * IMPORTANT:
     * Old data might be "wrapped", so we copy using:
     * old[(front + i) % old.length]
     */
    @SuppressWarnings("unchecked")
    public void ensureCapacity(int newCapacity) {

        AnyType[] old = theItems;
        theItems = (AnyType[]) new Object[newCapacity];

        if (old != null) {
            // Copy in LOGICAL order into new array starting at index 0
            for (int i = 0; i < theSize; i++) {
                theItems[i] = old[(front + i) % old.length];
            }
        }

        // After copying, logical order is now physically 0..theSize-1
        front = 0;
        back = theSize - 1;
    }

    /**
     * Adds x to the BACK of the logical structure.
     * Equivalent to enqueue behavior.
     */
    public void addLast(AnyType x) {
        if (theSize == theItems.length) {
            ensureCapacity(theItems.length * 2 + 1);
        }

        // move back forward circularly
        back = increment(back);

        // store the new element
        theItems[back] = x;
        theSize++;
    }

    /**
     * Removes and returns the FRONT element.
     * Equivalent to dequeue behavior.
     *
     * Returns null if empty (you can change this to throw if your rubric wants).
     */
    public AnyType removeFirst() {
        if (isEmpty()) {
            return null;
        }

        AnyType removed = theItems[front];
        theItems[front] = null; // helps garbage collection

        front = increment(front);
        theSize--;

        // If we became empty, reset indices to clean initial state
        if (theSize == 0) {
            front = 0;
            back = -1;
        }

        return removed;
    }

    /**
     * Iterator that walks the list in LOGICAL order:
     * front, front+1, ... wrapping around.
     *
     * It does NOT modify the structure.
     */
    private class CircularArrayIterator implements Iterator<AnyType> {
        private int seen = 0;       // how many items we've returned
        private int idx = front;    // current array index in circular sense

        @Override
        public boolean hasNext() {
            return seen < theSize;
        }

        @Override
        public AnyType next() {
            if (!hasNext()) throw new NoSuchElementException();

            AnyType item = theItems[idx];
            idx = increment(idx);
            seen++;
            return item;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove() not supported.");
        }
    }

    @Override
    public Iterator<AnyType> iterator() {
        return new CircularArrayIterator();
    }
}