package cs3345assignment1;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * BrowserLinkedList
 * -----------------
 * A CUSTOM doubly-linked list with two sentinel markers:
 * beginMarker <-> ...real nodes... <-> endMarker
 *
 * Sentinels simplify edge cases:
 * - no null checks when adding/removing at ends
 * - beginMarker.next is first real node (or endMarker if empty)
 * - endMarker.prev is last real node (or beginMarker if empty)
 */
public class BrowserLinkedList<AnyType> implements Iterable<AnyType> {

    /**
     * Node is static so it doesn't store an implicit reference to the outer list.
     */
    private static class Node<AnyType> {
        AnyType data;
        Node<AnyType> prev;
        Node<AnyType> next;

        Node(AnyType d, Node<AnyType> p, Node<AnyType> n) {
            data = d;
            prev = p;
            next = n;
        }
    }

    private int theSize;
    private Node<AnyType> beginMarker;
    private Node<AnyType> endMarker;

    public BrowserLinkedList() {
        doClear();
    }

    /**
     * Creates the two sentinels and links them together.
     */
    public void doClear() {
        beginMarker = new Node<>(null, null, null);
        endMarker = new Node<>(null, beginMarker, null);
        beginMarker.next = endMarker;
        theSize = 0;
    }

    /**
     * Helper: inserts x BEFORE node p.
     */
    private void addBefore(Node<AnyType> p, AnyType x) {
        Node<AnyType> newNode = new Node<>(x, p.prev, p);
        p.prev.next = newNode;
        p.prev = newNode;
        theSize++;
    }

    public void addFirst(AnyType x) {
        addBefore(beginMarker.next, x);
    }

    public void addLast(AnyType x) {
        addBefore(endMarker, x);
    }

    /**
     * Helper: removes node p and returns its data.
     */
    private AnyType remove(Node<AnyType> p) {
        p.prev.next = p.next;
        p.next.prev = p.prev;
        theSize--;
        return p.data;
    }

    public AnyType removeFirst() {
        if (theSize == 0) return null;
        return remove(beginMarker.next);
    }

    public AnyType removeLast() {
        if (theSize == 0) return null;
        return remove(endMarker.prev);
    }

    public int size() {
        return theSize;
    }

    public boolean isEmpty() {
        return theSize == 0;
    }

    /**
     * Iterator walks from first real node to endMarker.
     */
    private class LinkedListIterator implements Iterator<AnyType> {
        private Node<AnyType> current = beginMarker.next;

        @Override
        public boolean hasNext() {
            return current != endMarker;
        }

        @Override
        public AnyType next() {
            if (!hasNext()) throw new NoSuchElementException();
            AnyType nextItem = current.data;
            current = current.next;
            return nextItem;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove() not supported.");
        }
    }

    @Override
    public Iterator<AnyType> iterator() {
        return new LinkedListIterator();
    }
}